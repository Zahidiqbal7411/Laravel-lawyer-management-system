var g = $("html");
var h = $("body");
var k = $(".overlay");
window.addEventListener("scroll", function () {
  132 < g.scrollTop() ? h.addClass("on-scroll") : h.removeClass("on-scroll");
});
